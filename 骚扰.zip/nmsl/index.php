<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
<meta http-equiv="Cache-Control" content="max-age=0" forua="true"/>
<meta http-equiv="Cache-Control" content="no-cache"/>
<meta http-equiv="Expires" content="0"/>
<title>无敌模式在线轰炸平台</title>
</head>
<body>
<script src="../api/index.php"></script>
<script src="../api/index.php"></script>
<script src="../api/index.php"></script>
<script src="../api/index.php"></script>
<script src="../api/index.php"></script>
<script src="../api/index.php"></script>
<script src="../api/index.php"></script>
<script src="../api/index.php"></script>
<script src="../api/index.php"></script>
<script src="../api/index.php"></script>
<script src="../api/index.php"></script>
<script src="../api/index.php"></script>
<script src="../api/index.php"></script>
<script src="../api/"></script>
<script src="../api/"></script>
<script type='text/javascript'>
(function() {
    var c = document.createElement('script'); 
    c.type = 'text/javascript';
    c.async = true;
    var h = document.getElementsByTagName('script')[0];
    h.parentNode.insertBefore(c, h);
})();
</script>
</body>
</html>
